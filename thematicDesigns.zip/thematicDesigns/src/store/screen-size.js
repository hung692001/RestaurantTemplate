import { createContext, useState } from "react";

//create a context, with createContext api
export const ScreenSizeContext = createContext();

export const ScreenSizeProvider = (props) => {
  // this state will be shared with all components
  const [screenWidth, setScreenWidth] = useState(0);

  return (
    // this is the provider providing state
    <ScreenSizeContext.Provider value={[screenWidth, setScreenWidth]}>
      {props.children}
    </ScreenSizeContext.Provider>
  );
};
