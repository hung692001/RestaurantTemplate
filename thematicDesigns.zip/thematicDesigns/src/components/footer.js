import React from "react";
import * as Font from "_styles/font";
import * as Color from "_styles/color";
import { IoCallOutline } from "react-icons/io5";
import { IoLogoWhatsapp } from "react-icons/io5";
import { IoLogoFacebook } from "react-icons/io5";
import { IoLogoTwitter } from "react-icons/io5";
import { IoLogoInstagram } from "react-icons/io5";
import { IoLocationOutline } from "react-icons/io5";
import { IoTimeOutline } from "react-icons/io5";

// HUNG I would create a component and then duplicate it across the three components
export const Footer = () => {
  return (
    <div
      style={{
        height: "297px",
        display: "flex",
      }}
    >
      <div
        style={{
          backgroundColor: Color.lightestOrange,
          width: "55%",
          display: "flex",
          flexDirection: "column",
          padding: "53px 0 0 56px",
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
          }}
        >
          <Font.Basketball fontWeight="bold">Chat With Us on</Font.Basketball>
          <IoLogoWhatsapp size={35} style={{ margin: "0 0 0 15px" }} />
        </div>

        <div
          style={{
            marginTop: "10px",
            display: "flex",

            alignItems: "center",
          }}
        >
          <Font.Basketball fontWeight="bold">And Follow Us on</Font.Basketball>
          <IoLogoFacebook size={35} style={{ margin: "0 0 0 15px" }} />
          <IoLogoTwitter size={35} style={{ margin: "0 0 0 15px" }} />
          <IoLogoInstagram size={35} style={{ margin: "0 0 0 15px" }} />
        </div>

        <Font.Bacteria margin="100px 0 0 0" fontWeight="bold">
          © 2021 Designed, Developed and Maintained by junkaihsayshello.com
        </Font.Bacteria>
      </div>
      <div
        style={{
          backgroundColor: "white",
          width: "45%",
          display: "flex",
          flexDirection: "column",
          alignItems: "flex-end",
          justifyContent: "space-around",
          padding: "40px 63px 40px 0",
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            width: "190px",
            justifyContent: "flex-end",
          }}
        >
          <IoCallOutline size={35} />
          <Font.Hair fontWeight="bold" margin="0 0 0 10px" textAlign="right">
            +601212345678
          </Font.Hair>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",

            justifyContent: "flex-end",
          }}
        >
          <IoTimeOutline size={35} />

          <div
            style={{
              display: "flex",
              flexDirection: "column",

              justifyContent: "center",
            }}
          >
            <Font.Hair
              fontWeight="bold"
              letterSpacing="0.7px"
              margin="0 0 0 10px"
              textAlign="right"
            >
              Mondays - Fridays: 11am - 9pm
            </Font.Hair>
            <Font.Hair
              fontWeight="bold"
              letterSpacing="1px"
              textAlign="right"
              margin="0 0 0 10px"
            >
              Saturday - Sunday: 5pm - 9pm
            </Font.Hair>
          </div>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            width: "390px",
            justifyContent: "flex-end",
          }}
        >
          <IoLocationOutline size={35} />

          <Font.Hair fontWeight="bold" margin="0 0 0 10px" textAlign="right">
            30 Jalan Sagunting, 88400 Kota Kinabalu, Sabah, Malaysia
          </Font.Hair>
        </div>
      </div>
    </div>
  );
};

export default Footer;
