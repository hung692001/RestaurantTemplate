import { NavLink } from "react-router-dom";
import styled from "styled-components";
import * as Color from "_styles/color";
import * as Font from "_styles/mobilefont";

export const Button = styled.button`
  background-color: ${({ bgColor }) => bgColor || Color.darkBlue};
  box-sizing: ${({ boxSizing }) => boxSizing || "border-box"};
  color: ${({ color }) => color || Color.lighterOrange};
  padding: ${({ padding }) => padding || "10px 40px"};
  border: 1px solid ${({ border }) => border || Color.brightBlue};
  width: ${({ width }) => width || "330px"};
  height: ${({ height }) => height || "70px"};
  display: inline-block;
  margin: ${({ margin }) => margin || "5px"};
  cursor: pointer;
  align-self: ${({ alignSelf }) => alignSelf || "center"};
  justify-self: ${({ justifySelf }) => justifySelf || "center"};
  &:hover {
    background-color: ${({ hoverColor }) => hoverColor || Color.lightBlue};
  }
`;

export const MButton = styled.button`
  // position: ${({ pos }) => pos || "relative"};
  // left: 50%;
  // top: 50%;
  // -ms-transform: translate(-50%, -50%);
  // transform: translate(-50%, -50%);
  background-color: ${({ bgColor }) => bgColor || Color.darkBlue};
  box-sizing: ${({ boxSizing }) => boxSizing || "border-box"};
  color: ${({ color }) => color || Color.lighterOrange};
  padding: ${({ padding }) => padding || "1em"};
  border: 1px solid ${({ border }) => border || "transparent"};
  width: ${({ width }) => width || "45%"};
  min-width: 165px;
  height: ${({ height }) => height || "50px"};
  margin: ${({ margin }) => margin || "auto"};
  cursor: pointer;
  align-self: ${({ alignSelf }) => alignSelf || "center"};
  justify-self: ${({ justifySelf }) => justifySelf || "center"};
  text-align: center;
  &:hover {
    background-color: ${({ hoverColor }) => hoverColor || Color.lightBlue};
  }
  z-index: 10;
`;

export const MobileButton = ({ to, text, height }) => {
  return (
    <div
      style={{
        height: `${height}`,
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
      }}
    >
      <NavLink to={to}>
        <MButton>
          <Font.Human textAlign="center" color={Color.lighterOrange}>
            {text}
          </Font.Human>
        </MButton>
      </NavLink>
    </div>
  );
};
