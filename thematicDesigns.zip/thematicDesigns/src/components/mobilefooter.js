import React from "react";
import * as Font from "_styles/mobilefont";
import * as Color from "_styles/color";
import { IoCallOutline } from "react-icons/io5";
import { IoLogoWhatsapp } from "react-icons/io5";
import { IoLogoFacebook } from "react-icons/io5";
import { IoLogoTwitter } from "react-icons/io5";
import { IoLogoInstagram } from "react-icons/io5";
import { IoLocationOutline } from "react-icons/io5";
import { IoTimeOutline } from "react-icons/io5";
export const MobileFooter = () => {
  return (
    <div
      style={{
        height: "327px",
        backgroundColor: Color.lightestOrange,
        padding: "30px 0px 10px 30px",
        boxSizing: "border-box",
        width: "100%",
      }}
    >
      <div style={{ marginBottom: "33px" }}>
        {/*HUNG  Make Component */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            width: "132px",
            justifyContent: "space-between",
          }}
        >
          <Font.Human fontWeight="500">Chat With Us on</Font.Human>
          <IoLogoWhatsapp size={20} />
        </div>

        <div
          style={{
            display: "flex",
            width: "200px",
            justifyContent: "space-between",
            alignItems: "center",
            marginTop: "10px",
          }}
        >
          <Font.Human>And Follow Us on</Font.Human>
          <IoLogoFacebook size={20} />
          <IoLogoTwitter size={20} />
          <IoLogoInstagram size={20} />
        </div>
      </div>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
          }}
        >
          <IoCallOutline size={20} />
          <Font.Basketball fontWeight="bold" margin="0 0 0 10px">
            +601212345678
          </Font.Basketball>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",

            marginTop: "20px",
          }}
        >
          <IoTimeOutline size={20} />
          <div>
            <Font.Basketball
              fontWeight="bold"
              letterSpacing="0.85px"
              margin="0 0 0 10px"
            >
              Mondays - Fridays: 11am - 9pm
            </Font.Basketball>
            <Font.Basketball
              fontWeight="bold"
              letterSpacing="1px"
              margin="0 0 0 10px"
            >
              Saturday - Sunday: 5pm - 9pm
            </Font.Basketball>
          </div>
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",

            marginTop: "20px",
          }}
        >
          <IoLocationOutline size={20} />
          <Font.Basketball fontWeight="bold" margin="0 0 0 10px">
            30 Jalan Sagunting, 88400 Kota Kinabalu, Sabah, Malaysia
          </Font.Basketball>
        </div>
      </div>
      <Font.Hair margin="40px 0 0 0">
        © 2021 Designed, Developed and Maintained by junkaihsayshello.com
      </Font.Hair>
    </div>
  );
};

export default MobileFooter;
