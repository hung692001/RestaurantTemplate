import styled from "styled-components";

export const MobileBigTexts = styled.div`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  position: ${(props) => props.position || "relative"};
  display: ${(props) => props.display || "flex"};
  padding: ${(props) => props.padding || "0.5em"}
  height: ${(props) => props.height || "100px"};
  width: ${(props) => props.width || "100%"};
  margin-top: ${(props) => props.marginTop || "-0"};
  opacity:${(props) => props.opacity || "1"};
  z-index: 1;
`;

export const MobileImg = styled.img`
  alt: ${(props) => props.alt || ""};
  position: relative;
  margin: ${(props) => props.margin || "0"};
  width: 100%;
  max-height: ${(props) => props.maxHeight || "450px"};
  height: ${(props) => props.height || "100%"};
  min-width: 300px;
  object-fit: cover;
  zindex: 0;
`;
