import React, { useState, useEffect } from "react";
import * as Font from "_styles/font";
import * as Color from "_styles/color";

import logo from "_images/logo.png";

import { NavLink, Link } from "react-router-dom";

const navBarStyles = {
  display: "flex",
  backgroundColor: "transparent",
  position: "fixed",
  height: "90px",
  width: "100%",

  boxSizing: "border-box",
  zIndex: "9999",
};

const navColor = {
  height: "90px",
  width: "100%",
  transition: "background-color 0.3s ",
};

export const Header = (props) => {
  const [prevScrollPos, setPrevScrollPos] = useState(0);
  const [notTop, setNotTop] = useState(false);

  const [visible, setVisible] = useState(true);

  const handleScroll = debounce(() => {
    const currentScrollPos = window.pageYOffset;
    setVisible(prevScrollPos > currentScrollPos || currentScrollPos < 200);
    setNotTop(currentScrollPos > 20);
    setPrevScrollPos(currentScrollPos);
  }, 1);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [prevScrollPos, visible, handleScroll]);

  return (
    <div
      style={{
        ...navBarStyles,
        transition: "top 0.6s",
        top: visible ? "0px" : "-90px",
      }}
    >
      <div
        style={{
          ...navColor,
          backgroundColor: notTop ? "white" : "transparent",
          padding: "5px 0 5px 60px",
          boxSizing: "border-box",
        }}
      >
        <div
          style={{
            display: "flex",
            height: "100%",
            minWidth: "830px",
            marginRight: "660px",
            justifyContent: "space-between",
          }}
        >
          <Logo />
          <NavBarLinks text="Menu" to="/menu" />
          <NavBarLinks text="Order Online" to="/orderonline" />
          <NavBarLinks text="Our Story" to="/about" />
          <NavBarLinks text="Contact" to="/connectwithus" />
        </div>
      </div>
    </div>
  );
};

const Logo = () => {
  return (
    <Link to="/">
      <img
        src={logo}
        alt="logo"
        style={{
          height: "80px",
          justifyContent: "right",
        }}
      />
    </Link>
  );
};

const NavBarLinks = ({ to, text }) => {
  return (
    <NavLink
      style={{
        textDecoration: "none",
      }}
      activeStyle={{ color: Color.darkestOrange }}
      to={to}
    >
      <Font.Basketball margin="32px 40px" color={Color.darkestBlue}>
        {text}
      </Font.Basketball>
    </NavLink>
  );
};

function debounce(func, wait, immediate) {
  var timeout;
  return function () {
    var context = this,
      args = arguments;
    var later = function () {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}
