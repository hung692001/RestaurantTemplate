import { React, useCallback, useState, useEffect } from "react";
import { motion } from "framer-motion";
import { NavLink, Link } from "react-router-dom";
import styled from "styled-components";
import * as Color from "_styles/color";
import * as Font from "_styles/font";

import logo from "_images/logo.png";

import { HamburgerElastic } from "react-animated-burgers";
//JK to review
//ANDERSON find out how to stop initial animation
const MenuContainer = styled(motion.nav)`
  width: 150px;
  height: 100%;
  // max-width: 44%;
  background-color: #e1e1e1;
  box-shadow: -2px 2px 2px rgba(15, 15, 15, 0.3);
  z-index: 99;
  position: fixed;
  translate-x: 102%;
  // opacity: 1;
  top: 0;
  right: 0;
  padding: 1em 2.5em;
  user-select: none;
`;

function debounce(func, wait, immediate) {
  var timeout;
  return function () {
    var context = this,
      args = arguments;
    var later = function () {
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    var callNow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
    if (callNow) func.apply(context, args);
  };
}

const navBarStyles = {
  position: "fixed",
  background: "transparent",
  height: "72px",
  width: "100%",
  boxSizing: "border-box",
  alignItems: "center",
  zIndex: 9999,
};

const navColor = {
  display: "flex",
  height: "72px",
  width: "100%",
  padding: "0 15px",
  transition: "background-color 0.3s ",
  justifyContent: "space-between",
};

export const MobileHeader = () => {
  const [prevScrollPos, setPrevScrollPos] = useState(0);
  const [notTop, setNotTop] = useState(false);

  const [visible, setVisible] = useState(true);

  const handleScroll = debounce(() => {
    const currentScrollPos = window.pageYOffset;
    setVisible(prevScrollPos > currentScrollPos || currentScrollPos < 200);
    setNotTop(currentScrollPos > 20);
    setPrevScrollPos(currentScrollPos);
  }, 1);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [prevScrollPos, visible, handleScroll]);

  return (
    <div
      style={{
        ...navBarStyles,
        transition: "top 0.6s",
        top: visible ? "0px" : "-90px",
      }}
    >
      <div
        style={{
          ...navColor,
          backgroundColor: notTop ? "white" : "transparent",
          boxSizing: "border-box",
        }}
      >
        <Logo />
        <MobileMenu visible={visible} />
      </div>
    </div>
  );
};

const menuVariants = {
  open: {
    translateX: "0%",
    opacity: 1,
  },
  closed: {
    translateX: "102%",
    // opacity: 0,
  },
};

const menuTransition = {
  type: "backInOut",
  duration: 0.3,
  stiffness: 1000,
  delay: 0.1,
};

function MobileMenu({ visible }) {
  const [isActive, setIsActive] = useState(false);

  const toggleButton = useCallback(() => {
    setIsActive((prevState) => !prevState);
  }, []);

  return (
    <div style={{ display: "flex" }}>
      <HamburgerElastic
        style={{
          height: "100%",
          zIndex: "100",
        }}
        buttonColor="transparent"
        barColor="black"
        {...{ isActive, toggleButton }}
      />
      <MenuContainer
        animate={isActive && visible ? "open" : "closed"}
        variants={menuVariants}
        transition={menuTransition}
      >
        <NavMenu />
      </MenuContainer>
    </div>
  );
}

function NavMenu(props) {
  return (
    <div
      style={{
        padding: "50px 0 0 0 ",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <NavBarContent text="Menu" to="/mobilemenu" />
      <NavBarContent text="Order Online" to="/aboutpagemobile" />
      <NavBarContent text="Our Story" to="/aboutpagemobile" />
      <NavBarContent text="Contact" to="/connectwithusmobile" />
    </div>
  );
}

const NavBarContent = ({ text, to }) => {
  return (
    <NavLink
      style={{
        textDecoration: "none",
        margin: "0.5em 0",
      }}
      activeStyle={{ color: Color.darkestOrange }}
      to={to}
    >
      <Font.Basketball color={Color.darkestBlue}>{text}</Font.Basketball>
    </NavLink>
  );
};

const Logo = () => {
  return (
    <Link to="/mobilehome">
      <img
        src={logo}
        alt="logo"
        style={{
          marginTop: "10px",
          height: "50px",
          width: "50px",
        }}
      />
    </Link>
  );
};
