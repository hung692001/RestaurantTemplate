import styled from "styled-components";
//These are the font styles that will be used throughout this thematic website

export const Sun = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 24px;
  margin: ${(props) => props.margin || 0};
  width: ${(props) => props.width || "auto"};
  padding: ${(props) => props.padding || 0};
  text-align: ${(props) => props.textAlign || "left"};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: bold;
`;

export const Jupiter = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 20px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  text-align: ${(props) => props.textAlign || "left"};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
`;

export const Earth = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 18px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
`;

export const Ocean = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 16px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
`;

export const Human = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 14px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: ${(props) => props.fontWeight || "medium"};
  width: ${(props) => props.width || "auto"};
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Basketball = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 12px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  text-align: ${(props) => props.textAlign || "left"};
  letter-spacing: ${(props) => props.letterSpacing || "normal"};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
`;

export const Hair = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 10px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: ${(props) => props.fontWeight || "medium"};
  width: ${(props) => props.width || "auto"};
`;

export const Bacteria = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 8px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
`;

export const Electron = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 6px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
`;
