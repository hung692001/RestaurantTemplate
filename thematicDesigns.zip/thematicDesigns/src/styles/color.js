//shades of blue used for development
export const darkestBlue = "#035388";
export const darkerBlue = "#0B69A3";
export const darkBlue = "#127FBF";
export const blue = "#1992D4";
export const lightBlue = "#2BB0ED";
export const lighterBlue = "#40C3F7";
export const lightestBlue = "#5ED0FA";
export const brightBlue = "#81DEFD";
export const brighterBlue = "#B3ECFF";
export const brightestBlue = "#E3F8FF";

//shades of orange used for development
export const darkestOrange = "#8D2B0B";
export const darkerOrange = "#B44D12";
export const darkOrange = "#CB6E17";
export const orange = "#DE911D";
export const lightOrange = "#F0B429";
export const lighterOrange = "#F7C948";
export const lightestOrange = "#FADB5F";
export const brightOrange = "#FCE588";
export const brighterOrange = "#FFF3C4";
export const brightestOrange = "#FFFBEA";
