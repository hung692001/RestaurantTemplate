import styled from "styled-components";
//These are the font styles that will be used throughout this thematic website

export const Sun = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 80px;
  margin: ${(props) => props.margin || 0};
  width: ${(props) => props.width || "auto"};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: bold;
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Jupiter = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 64px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  width: ${(props) => props.width || "auto"};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Earth = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 48px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Ocean = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 36px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Human = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 28px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Basketball = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 22px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  width: ${(props) => props.width || "auto"};
  align-self: ${({ props }) => props || "center"};
  justify-self: ${({ props }) => props || "center"};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: ${(props) => props.fontWeight || "medium"};
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Hair = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 18px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: ${(props) => props.fontWeight || "medium"};
  width: ${(props) => props.width || "auto"};
  letter-spacing: ${(props) => props.letterSpacing || "normal"};
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Bacteria = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 15px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: ${(props) => props.fontWeight || "medium"};
  text-align: ${(props) => props.textAlign || "left"};
`;

export const Electron = styled.p`
  background-color: ${(props) => props.backgroundColor || "transparent"};
  color: ${(props) => props.color || "black"};
  font-size: 12px;
  margin: ${(props) => props.margin || 0};
  padding: ${(props) => props.padding || 0};
  font-family: -apple-system, BlinkMacSystemFont, sans-serif;
  font-weight: medium;
  text-align: ${(props) => props.textAlign || "left"};
`;
