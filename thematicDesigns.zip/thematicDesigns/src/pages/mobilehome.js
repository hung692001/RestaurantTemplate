import React from "react";
import * as Color from "_styles/color";
import * as Font from "_styles/mobilefont";
import * as Buttons from "_components/button";

import home1 from "_images/home1.jpg";
import home2 from "_images/home2.jpg";
import home3_3 from "_images/home3-3.jpg";
import home3_2 from "_images/home3-2.jpg";
import home4 from "_images/home4.jpg";

import { MobileHeader } from "_components/header/mobile";
import MobileFooter from "_components/mobilefooter";
import { MobileBigTexts, MobileImg } from "_components/mobilelanding";

export const MobileHome = () => {
  return (
    <div>
      <MobileHeader />
      <Intro />
      <Order />
      <Story />
      <Contact />
      <Samples />
      <MobileFooter />
    </div>
  );
};

const Intro = () => {
  return (
    <div
      style={{
        backgroundColor: Color.lighterOrange,
        width: "100%",
        minWidth: "300px",
        zIndex: "-1",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          height: "450px",
          backgroundImage: `url(${home1})`,
          backgroundSize: "cover",
          padding: "200px 0 0 0",
          boxSizing: "border-box",
          alignContent: "center",
          justifyContent: "center",
        }}
      >
        <MobileBigTexts
          flexDirection="column"
          backgroundColor={Color.lighterOrange}
        >
          <Font.Sun color={"white"} margin="1em" textAlign="center">
            Your Favourite Korean Foods Just an Order Away
          </Font.Sun>
        </MobileBigTexts>
        <Buttons.MobileButton
          height="135px"
          to="/mobilemenu"
          text="Check Out Menu Now"
        />
      </div>
    </div>
  );
};

const Order = () => {
  return (
    <div
      style={{
        backgroundColor: Color.brighterBlue,
        height: "470px",
        width: "100%",
        minWidth: "300px",
        zIndex: "-1",
      }}
    >
      <MobileBigTexts
        height="130px"
        flexDirection="column"
        backgroundColor={Color.brighterBlue}
      >
        <Font.Sun color={Color.darkBlue} margin="2em 1em" textAlign="center">
          Try Our Signature Korean Fried Chicken
        </Font.Sun>
      </MobileBigTexts>
      <div
        style={{
          height: "340px",
          backgroundImage: `url(${home2})`,
          backgroundSize: "cover",
          padding: "0",
          boxSizing: "border-box",
          alignContent: "center",
          justifyContent: "center",
        }}
      >
        <Buttons.MobileButton
          height="500px"
          to="/mobilemenu"
          text="Order Now"
        />
      </div>
    </div>
  );
};

//to cont
const Story = () => {
  return (
    <div
      style={{
        position: "relative",
        backgroundColor: Color.darkerOrange,
        height: "595px",
        width: "100%",
        minWidth: "300px",
        zIndex: "0",
      }}
    >
      <MobileBigTexts
        display="block"
        backgroundColor={Color.darkerOrange}
        style={{
          padding: "0.5em",
          maxHeight: "130px",
          boxSizing: "border-box",
        }}
      >
        <Font.Jupiter
          color={Color.brightestOrange}
          margin="2em 3em"
          textAlign="center"
        >
          A recipe perfected over 5 generations
        </Font.Jupiter>
      </MobileBigTexts>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          height: "365px",
        }}
      >
        <img
          src={home3_2}
          alt=""
          style={{
            margin: "0 0% auto auto",
            objectFit: "cover",
            minHeight: "240px",
            // minWidth: "160px",
            width: "45%",
          }}
        />
        <img
          src={home3_3}
          alt=""
          style={{
            objectFit: "cover",
            margin: "-420px auto 0 0%",
            minHeight: "240px",
            // minWidth: "330px",
            width: "45%",
          }}
        />
      </div>
      <Buttons.MobileButton
        height="100px"
        to="/aboutpagemobile"
        text="Check Out Our Story"
      />
    </div>
  );
};
const Contact = () => {
  return (
    <div
      style={{
        backgroundColor: Color.lighterOrange,
        width: "100%",
        minWidth: "300px",
        zIndex: "-1",
        justifyContent: "center",
      }}
    >
      <div
        style={{
          height: "400px",
          width: "100%",
          backgroundImage: `url(${home4})`,
          // backgroundSize: "cover",
          padding: "220px 0 0 0",
          boxSizing: "border-box",
          alignContent: "center",
          justifyContent: "center",
        }}
      >
        <MobileBigTexts
          display="block"
          backgroundColor={Color.darkerBlue}
          style={{
            padding: "0.1em",
            minHeight: "30px",
            boxSizing: "border-box",
          }}
        >
          <Font.Jupiter
            color={Color.brightestOrange}
            margin="1em"
            textAlign="center"
          >
            Dine with family and friends
          </Font.Jupiter>
        </MobileBigTexts>
        <Buttons.MobileButton
          height="105px"
          to="/connectwithusmobile"
          text="Contact Us"
        />
      </div>
    </div>
  );
};

const Samples = () => {
  return (
    <div
      style={{
        position: "relative",
        backgroundColor: Color.lighterOrange,
        height: "auto",
        width: "100%",
        minWidth: "300px",
        zIndex: "-1",
        justifyContent: "center",
      }}
    >
      <Sample
        image={home1}
        title="Japchae"
        description="Something nice about japchae"
      />
      <Sample
        image={home1}
        title="Japchae"
        description="Something nice about japchae"
      />
      <Sample
        image={home1}
        title="Japchae"
        description="Something nice about japchae"
      />
    </div>
  );
};

const Sample = ({ image, title, description }) => {
  return (
    <div style={{ height: "415px" }}>
      <MobileImg src={image} />
      <MobileBigTexts
        style={{
          height: "auto",
          padding: "1em",
          marginTop: "-180px",
          boxSizing: "border-box",
        }}
        display="block"
        opacity="0.65"
        backgroundColor={"white"}
      >
        <Font.Jupiter color={"black"} margin="0.2em" textAlign="center">
          {title}
        </Font.Jupiter>
        <Font.Basketball color={"black"} margin="0.2em" textAlign="center">
          {description}
        </Font.Basketball>
      </MobileBigTexts>
    </div>
  );
};
