import React, { useContext } from "react";
import { useState } from "react";
import "_styles/index.css";
import * as Font from "_styles/font";
import * as Color from "_styles/color";
import { Button } from "_components/button";
import { Footer } from "_components/footer";
import { Header } from "_components/header";
import RestaurantImg from "_images/Restaurant1.jpg";
//JK TO REVIEW

export const ConnectWithUs = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [message, setMessage] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(firstName);
    console.log(lastName);
    console.log(email);
    console.log(phoneNumber);
    console.log(message);
    setFirstName("");
    setLastName("");
    setEmail("");
    setPhoneNumber("");
    setMessage("");
  };
  return (
    <div>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
        }}
      >
        <Header />
        <div
          style={{
            height: "545px",
            width: "100%",
            backgroundColor: Color.brighterOrange,
            position: "absolute",
            zIndex: -9,
          }}
        ></div>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-end",
            margin: "0 auto ",
            zIndex: 1,
          }}
        >
          <Font.Sun color={Color.darkestOrange} margin="147px 0 75px 0">
            Connect With Us
          </Font.Sun>
          <form
            style={{
              width: "1100px",
              height: "677px",
              backgroundColor: Color.brightBlue,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
            onSubmit={handleSubmit}
          >
            <Font.Earth
              padding="54px 0px 48px 0px"
              color={Color.darkestBlue}
              width="100%"
            >
              We Want To Hear From You
            </Font.Earth>
            <div style={{ display: "flex" }}>
              <div
                style={{
                  width: "523px",
                  height: "326px",
                  paddingLeft: "38px",
                  boxSizing: "border-box",
                }}
              >
                <Font.Basketball margin="0 0 9px 0" color={Color.darkestBlue}>
                  First Name
                </Font.Basketball>
                <input
                  style={{
                    width: "353px",
                    height: "45px",
                    border: "3px solid #035388",
                    backgroundColor: "transparent",
                    fontSize: "28px",
                  }}
                  type="text"
                  value={firstName}
                  onChange={(e) => setFirstName(e.target.value)}
                />
                <Font.Basketball
                  margin="34px 0 9px 0"
                  color={Color.darkestBlue}
                >
                  Last Name
                </Font.Basketball>
                <input
                  type="text"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  style={{
                    width: "353px",
                    height: "45px",
                    border: "3px solid #035388",
                    backgroundColor: "transparent",
                    fontSize: "28px",
                  }}
                />
                <Font.Basketball
                  margin="34px 0 9px 0"
                  color={Color.darkestBlue}
                >
                  Email
                </Font.Basketball>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  style={{
                    width: "353px",
                    height: "45px",
                    border: "3px solid #035388",
                    backgroundColor: "transparent",
                    fontSize: "28px",
                  }}
                />
              </div>
              <div
                style={{
                  width: "577px",
                  height: "326px",
                }}
              >
                <Font.Basketball margin="0 0 9px 0" color={Color.darkestBlue}>
                  Phone Number
                </Font.Basketball>
                <input
                  type="number"
                  value={phoneNumber}
                  onChange={(e) => setPhoneNumber(e.target.value)}
                  style={{
                    width: "353px",
                    height: "45px",
                    border: "3px solid #035388",
                    backgroundColor: "transparent",
                    fontSize: "28px",
                  }}
                />
                <Font.Basketball
                  margin="34px 0 9px 0"
                  color={Color.darkestBlue}
                >
                  Leave Us a Message
                </Font.Basketball>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  style={{
                    width: "484px",
                    height: "165px",
                    border: "3px solid #035388",
                    backgroundColor: "transparent",
                    fontSize: "28px",
                  }}
                />
              </div>
            </div>
            <Button margin="57px 0 0 0">
              <input
                type="submit"
                style={{
                  backgroundColor: "transparent",
                  border: "none",
                  color: "white",
                  fontSize: "22px",
                }}
                value="Send Message"
              />
            </Button>
          </form>
        </div>
        <img
          src={RestaurantImg}
          alt="Restaurant"
          style={{
            zIndex: -4,
            marginTop: "-192px",
            height: "662px",
          }}
        />
        <Font.Jupiter
          color={Color.darkestBlue}
          backgroundColor={Color.brightestBlue}
          width="216px"
          padding="29px 590px 73px 59px"
          margin="-67px 0 0 0"
        >
          Visit Us
        </Font.Jupiter>

        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3682.2219136743156!2d14.524174215370863!3d-22.645513285145302!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1c76591260f6c1ef%3A0x1a2a19e24723dc9d!2sRandom%20Cafe!5e0!3m2!1sen!2smy!4v1639663136954!5m2!1sen!2smy"
          width="100%"
          height="620"
          frameborder="0"
          style={{ border: 0 }}
          allowfullscreen=""
          aria-hidden="false"
          tabindex="0"
          style={{ display: "block", padding: 0, margin: 0 }}
        ></iframe>
      </div>
      <Footer />
    </div>
  );
};

export default ConnectWithUs;
