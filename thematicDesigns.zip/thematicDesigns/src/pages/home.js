import React, { useContext } from "react";

import { Header } from "_components/header";
import { Greet } from "_pages/landing/greet";
import { Suggestion } from "_pages/landing/suggestion";
import { LearnMore } from "_pages/landing/learnmore";
import { LandingContact } from "_pages/landing/landingcontact";
import { SampleMenu } from "_pages/landing/samplemenu";
import { Footer } from "_components/footer";

import { ScreenSizeContext } from "_store/screen-size";
//JK TO DO THE SWITHC DEPENDING ON SCREEN SIZE

export const HomePage = () => {
  const [screenWidth, setScreenWidth] = useContext(ScreenSizeContext);
  return (
    <div
      style={{
        backgroundColor: "white",
        width: "100%",
        height: "100vh",
        margin: "0",
        padding: 0,
      }}
    >
      <Header />
      <Greet />
      <Suggestion />
      <LearnMore />
      <LandingContact />
      <SampleMenu />
      <Footer />
    </div>
  );
};
