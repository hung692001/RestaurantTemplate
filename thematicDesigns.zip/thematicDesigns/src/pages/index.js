import React, { useEffect, useContext } from "react";
import { BrowserRouter as Switch, Route } from "react-router-dom";
import { HomePage } from "_pages/home";
import { AboutPage } from "_pages/about";
// import { ScreenSizeContext } from "_store/screen-size";
import { AboutPageMobile } from "_pages/aboutmobile";
import { MobileFooter } from "_components/mobilefooter";
import { ConnectWithUs } from "_pages/connectwithus";
import { MenuPage } from "_pages/menu";
import { MobileHome } from "_pages/mobilehome";
import { ConnectWithUsMobile } from "_pages/connectwithusmobile";
import { MobileMenuPage } from "_pages/mobilemenu";
export const Routing = () => {
  // const [screenWidth, setScreenWidth] = useContext(ScreenSizeContext);
  // useEffect(() => {
  //   updateDimensions();

  //   window.addEventListener("resize", updateDimensions);
  //   return () => window.removeEventListener("resize", updateDimensions);
  // }, []);
  // const updateDimensions = () => {
  //   const width = window.innerWidth;
  //   setScreenWidth(width);
  // };
  return (
    <Switch>
      <Route path="/about">
        <AboutPage />
      </Route>
      <Route path="/aboutpagemobile">
        <AboutPageMobile />
      </Route>
      <Route path="/menu">
        <MenuPage />
      </Route>
      <Route path="/mobilemenu">
        <MobileMenuPage />
      </Route>
      <Route path="/connectwithusmobile">
        <ConnectWithUsMobile />
      </Route>
      <Route path="/mobilefooter">
        <MobileFooter />
      </Route>
      <Route path="/connectwithus">
        <ConnectWithUs />
      </Route>
      <Route path="/mobilehome">
        <MobileHome />
      </Route>
      <Route exact path="/">
        <HomePage />
      </Route>
    </Switch>
  );
};
