import React, { useContext } from "react";
import * as Color from "_styles/color";
import * as Font from "_styles/mobilefont";

import home4_1 from "_images/home4-1.jpg";
import home4_2 from "_images/home4-2.jpg";

import { MobileHeader } from "_components/header/mobile";
import MobileFooter from "_components/mobilefooter";
import styled from "styled-components";

const TopContainer = () => {
  return (
    <div
      style={{
        // position: "relative",
        height: "120px",
        backgroundColor: Color.orange,
        width: "100%",
        padding: "72px 1em 0 1em",
        boxSizing: "border-box",
        zIndex: "1",
      }}
    >
      <Font.Sun style={{ textAlign: "center", color: Color.brightestOrange }}>
        Menu
      </Font.Sun>
    </div>
  );
};

//Labels use Font.Earth
const Labels = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 50px;
  width: 100%;
  z-index: 99;
  padding: 1.5em;
  box-sizing: border-box;
`;

const Section = ({ color, sectionName }) => {
  return (
    <Labels>
      <Font.Earth color={color}>{sectionName}</Font.Earth>
    </Labels>
  );
};

export const MobileMenuPage = () => {
  return (
    <div style={{ width: "100%", minWidth: "300px" }}>
      <MobileHeader />
      <TopContainer />
      <Section id="Stew" color={Color.brightestOrange} sectionName="Stew" />
      <StewBG />
      <ScrollGrid />

      <Section id="Stew" color={Color.darkerOrange} sectionName="Noodles" />
      <NoodleBG />
      <ScrollGrid />

      <Section id="Stew" color={Color.darkerBlue} sectionName="Drinks" />
      <DrinksBG />
      <ScrollGrid />

      <MobileFooter />
    </div>
  );
};

const ScrollGrid = () => {
  return (
    <div
      style={{
        display: "flex",
        marginTop: "-480px",
        height: "480px",
        // padding: "0 2.5%",
        overflowX: "auto",
        overflowY: "hidden",
      }}
    >
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
    </div>
  );
};

const MenuContent = ({ image1, image2, text1, text2 }) => {
  return (
    <div
      style={{
        padding: "20px",
        height: "480px",
        boxSizing: "border-box",
        textAlign: "center",
      }}
    >
      <div style={{ height: "240px", width: "160px" }}>
        <img
          src={image1}
          style={{ width: "100%", height: "65%", objectFit: "cover" }}
        />
        <Font.Ocean margin="15px">{text1}</Font.Ocean>
      </div>
      <div style={{ height: "240px", width: "160px" }}>
        <img
          src={image2}
          style={{ width: "100%", height: "65%", objectFit: "cover" }}
        />
        <Font.Ocean margin="15px">{text2}</Font.Ocean>
      </div>
    </div>
  );
};

const StewBG = () => {
  return (
    <div style={{ height: "530px" }}>
      <div
        style={{
          position: "relative",
          backgroundColor: Color.orange,
          height: "187.5px",
          marginTop: "-50px",
          zIndex: "-1",
        }}
      />
      <div
        style={{
          position: "relative",
          height: "197.5px",
          zIndex: "-1",
        }}
      />
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brighterBlue,
          width: "60%",
          height: "63px",
          zIndex: "-1",
          marginTop: "-125px",
          marginRight: "0",
          marginLeft: "auto",
        }}
      />
    </div>
  );
};

const NoodleBG = () => {
  return (
    <div style={{ height: "530px" }}>
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brightOrange,
          height: "110px",
          width: "85%",
          marginTop: "-50px",
          zIndex: "-1",
        }}
      />
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brighterBlue,
          width: "60%",
          height: "150px",
          zIndex: "-1",
          marginTop: "310px",
          marginRight: "5%",
          marginLeft: "auto",
        }}
      />{" "}
    </div>
  );
};

const DrinksBG = () => {
  return (
    <div style={{ height: "530px" }}>
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brightestBlue,
          height: "310px",
          width: "30%",
          marginTop: "-50px",
          zIndex: "-1",
        }}
      />
    </div>
  );
};
