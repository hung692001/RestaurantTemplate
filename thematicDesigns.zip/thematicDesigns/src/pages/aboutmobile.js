import React from "react";
import * as Font from "_styles/mobilefont";
import * as Color from "_styles/color";
import image1 from "_images/MobileFoodPic1.png";
import image2 from "_images/MobileFoodPic2.png";
import { MobileFooter } from "_components/mobilefooter";
import { MobileHeader } from "_components/header/mobile";
//JK TO REVIEW
export const AboutPageMobile = () => {
  return (
    <div>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          backgroundColor: Color.darkerOrange,
        }}
      >
        <MobileHeader />

        <Font.Sun
          color="white"
          width="100%"
          backgroundColor={Color.darkerOrange}
          margin="72px 0 0 0 "
          padding="0 0 20px 0"
          textAlign="center"
        >
          Our Story
        </Font.Sun>

        <img
          src={image1}
          alt="Food"
          style={{ width: "100%", display: "block" }}
        />
        <div
          style={{
            backgroundColor: Color.brightOrange,
            height: "194px",
            display: "flex",
            flexDirection: "column",
            padding: "20px",
            justifyContent: "flex-start",
            alignItems: "center",
            boxSizing: "border-box",
          }}
        >
          <Font.Jupiter color={Color.darkestBlue}>
            From our roots in Gwangdu, Busan
          </Font.Jupiter>
          <br />
          <Font.Basketball padding="0 50px 0 50px" textAlign="center">
            I'm a paragraph. Click here to add your own text and edit me. It’s
            easy. Just click “Edit Text” or double click me to add your own
            content and make changes to the font. I’m a great place for you to
            tell a story and let your users know a little more about you.
          </Font.Basketball>
        </div>
        <div
          style={{
            height: "100px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "white",
            width: "100%",
          }}
        >
          <Font.Jupiter color={Color.darkestOrange} textAlign="center">
            Our famous delicacies perfected over 300 years
          </Font.Jupiter>
        </div>
        <img
          src={image2}
          alt="Food2"
          style={{ width: "100%", display: "block" }}
        />
        <div
          style={{
            height: "152px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "white",
          }}
        >
          <Font.Basketball color={Color.darkestOrange} padding="0 50px 0 50px">
            I'm a paragraph. Click here to add your own text and edit me. It’s
            easy. Just click “Edit Text” or double click me to add your own
            content and make changes to the font. I’m a great place for you to
            tell a story and let your users know a little more about you.
          </Font.Basketball>
        </div>
      </div>
      <MobileFooter />
    </div>
  );
};

export default AboutPageMobile;
