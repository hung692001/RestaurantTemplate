import React, { useContext } from "react";
import * as Color from "_styles/color";
import * as Font from "_styles/font";

import home4_1 from "_images/home4-1.jpg";
import home4_2 from "_images/home4-2.jpg";

import { Header } from "_components/header";
import { Footer } from "_components/footer";
import styled from "styled-components";

const TopContainer = () => {
  return (
    <div
      style={{
        // position: "relative",
        height: "240px",
        backgroundColor: Color.orange,
        width: "100%",
        padding: "140px 1em 0 1em",
        boxSizing: "border-box",
        zIndex: "1",
      }}
    >
      <Font.Sun style={{ textAlign: "center", color: Color.brightestOrange }}>
        Menu
      </Font.Sun>
    </div>
  );
};

//Labels use Font.Earth
const Labels = styled.div`
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 50px;
  width: 100%;
  z-index: 99;
  padding: 1.5em;
  box-sizing: border-box;
`;

const Section = ({ color, sectionName, margin }) => {
  return (
    <Labels>
      <Font.Ocean margin={margin} color={color}>
        {sectionName}
      </Font.Ocean>
    </Labels>
  );
};

export const MenuPage = () => {
  return (
    <div style={{ width: "100%", minWidth: "830px" }}>
      <Header />
      <TopContainer />
      <Section
        margin="0 50px"
        color={Color.brightestOrange}
        sectionName="Stew"
      />
      <StewBG />
      <ScrollGrid />

      <Section
        margin="0 auto 0 120px"
        color={Color.darkerOrange}
        sectionName="Noodles"
      />
      <NoodleBG />
      <ScrollGrid />

      <Section
        margin="0 auto 0 900px"
        color={Color.darkerBlue}
        sectionName="Drinks"
      />
      <DrinksBG />
      <ScrollGrid />

      <Footer />
    </div>
  );
};

const ScrollGrid = () => {
  return (
    <div
      style={{
        display: "flex",
        marginTop: "-480px",
        height: "700px",
        // padding: "0 2.5%",
        overflowX: "auto",
        overflowY: "hidden",
      }}
    >
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
      <MenuContent
        image1={home4_2}
        text1="Pizza"
        image2={home4_1}
        text2="Japchae"
      />
      <MenuContent
        image1={home4_1}
        text1="Japchae"
        image2={home4_2}
        text2="Pizza"
      />
    </div>
  );
};

const MenuContent = ({ image1, image2, text1, text2 }) => {
  return (
    <div
      style={{
        padding: "40px",
        width: "400px",
        height: "700px",
        boxSizing: "border-box",
      }}
    >
      <div style={{ height: "300px", width: "220px" }}>
        <img
          src={image1}
          style={{ width: "220px", height: "220px", objectFit: "cover" }}
        />
        <Font.Basketball margin="10px 0">{text1}</Font.Basketball>
      </div>
      <div style={{ height: "300px", width: "220px" }}>
        <img
          src={image2}
          style={{ width: "100%", height: "220px", objectFit: "cover" }}
        />
        <Font.Basketball margin="10px 0">{text2}</Font.Basketball>
      </div>
    </div>
  );
};

const StewBG = () => {
  return (
    <div style={{ height: "530px" }}>
      <div
        style={{
          position: "relative",
          backgroundColor: Color.orange,
          height: "187.5px",
          marginTop: "-50px",
          zIndex: "-1",
        }}
      />
      <div
        style={{
          position: "relative",
          height: "197.5px",
          zIndex: "-1",
        }}
      />
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brighterBlue,
          width: "60%",
          height: "180px",
          zIndex: "-1",
          marginTop: "60px",
          marginRight: "0",
          marginLeft: "auto",
        }}
      />
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brightOrange,
          width: "85%",
          height: "80px",
          zIndex: "-1",
          margin: "70px auto 0 0",
        }}
      />
    </div>
  );
};

const NoodleBG = () => {
  return (
    <div style={{ height: "530px" }}>
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brightOrange,
          height: "200px",
          width: "85%",
          marginTop: "-50px",
          zIndex: "-1",
        }}
      />
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brighterBlue,
          width: "60%",
          height: "250px",
          zIndex: "-1",
          marginTop: "180px",
          marginRight: "25%",
          marginLeft: "auto",
        }}
      />
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brightestBlue,
          height: "310px",
          width: "55%",
          margin: "90px auto auto 450px",
          zIndex: "-1",
        }}
      />
    </div>
  );
};

const DrinksBG = () => {
  return (
    <div style={{ height: "530px" }}>
      <div
        style={{
          position: "relative",
          backgroundColor: Color.brightestBlue,
          height: "380px",
          width: "55%",
          margin: "-50px auto auto 450px",
          zIndex: "-1",
        }}
      />
    </div>
  );
};
