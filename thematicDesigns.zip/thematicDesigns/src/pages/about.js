import React, { useContext } from "react";
import "_styles/index.css";
import image1 from "_images/vegetable_stir_fry.jpg";
import image2 from "_images/ingredients.jpeg";
import * as Font from "_styles/font";
import * as Color from "_styles/color";
import { ScreenSizeContext } from "_store/screen-size";
import { Footer } from "_components/footer";
import { Header } from "_components/header";
export const AboutPage = () => {
  return (
    <div>
      <div
        style={{
          backgroundColor: Color.darkerOrange,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          height: "900px",
        }}
      >
        <Header />
        <Font.Sun color="white" margin="150px 0 0 0">
          Our Story
        </Font.Sun>

        <div
          style={{
            display: "flex",
            height: "750px",
            width: "934px",
            marginTop: "60px",
          }}
        >
          <img
            src={image1}
            alt="Wok"
            style={{ width: "50%", height: "678px", objectFit: "cover" }}
          />
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              height: "678px",
              width: "50%",
              padding: "105px 38px 0 49px",
              backgroundColor: Color.brightOrange,
              boxSizing: "border-box",
            }}
          >
            <Font.Ocean color={Color.darkerBlue}>Generic Title</Font.Ocean>

            <Font.Hair
              color={Color.darkerBlue}
              width="350px"
              margin="50px 0 0 0 "
            >
              Lorem, ipsum dolor sit amet consectetur adipisicing elit.
              Distinctio porro maiores eius nam repudiandae esse soluta sint,
              enim ad sapiente. Doloribus facere nostrum autem quam rem natus
              vero alias repellat.
            </Font.Hair>
          </div>
        </div>
      </div>
      <div
        style={{
          display: "flex",
          height: "409px",
          margin: "229px 0 109px 0",
          boxSizing: "border-box",
          padding: "0 141px 0 195px",
          justifyContent: "center",
        }}
      >
        <div
          style={{
            width: "551px",
            display: "flex",
            flexDirection: "column",
            boxSizing: "border-box",
            padding: "38px 120px 0 0",
          }}
        >
          <Font.Ocean color={Color.darkestOrange}>Generic Title</Font.Ocean>

          <Font.Hair color="black" margin="50px 0 0 0 ">
            Lorem ipsum dolor sit amet consectetur adipisicing elit.
            Perspiciatis ducimus commodi incidunt molestiae itaque,
            reprehenderit consequuntur distinctio cumque in. Laboriosam
            molestias rerum explicabo a modi sequi sint illum vel ad.
          </Font.Hair>
        </div>
        <img
          src={image2}
          alt="Ingredients"
          style={{
            height: "100%",
            width: "553px",
            objectFit: "cover",
          }}
        />
      </div>
      <Footer />
    </div>
  );
};
