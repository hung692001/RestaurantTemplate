import React from "react";
import { useState } from "react";
import { MButton } from "_components/button";
import * as Font from "_styles/mobilefont";
import * as Color from "_styles/color";
import RestaurantImg from "_images/Restaurant1.jpg";
import { MobileFooter } from "_components/mobilefooter";
import { MobileHeader } from "_components/header/mobile";
//JK TO REVIEW
export const ConnectWithUsMobile = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [message, setMessage] = useState("");
  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(firstName);
    console.log(lastName);
    console.log(email);
    console.log(phoneNumber);
    console.log(message);
    setFirstName("");
    setLastName("");
    setEmail("");
    setPhoneNumber("");
    setMessage("");
  };
  return (
    <div>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <MobileHeader />
        <div
          style={{
            height: "600px",
            width: "100%",
            backgroundColor: Color.brighterOrange,
          }}
        >
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <Font.Sun color={Color.darkestOrange} margin="72px 0 30px 0">
              Connect With Us
            </Font.Sun>

            <form
              style={{
                width: "351px",
                padding: "12px 0 0 0 ",
                boxSizing: "border-box",
                backgroundColor: Color.brightBlue,
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
              }}
              onSubmit={handleSubmit}
            >
              <Font.Earth color={Color.darkestBlue} width="100%">
                We Want To Hear From You
              </Font.Earth>
              <div
                style={{
                  width: "351px",
                  paddingTop: "26px",
                  paddingLeft: "26px",
                  boxSizing: "border-box",
                  font: "18px",
                }}
              >
                <Input
                  Type="text"
                  Value={firstName}
                  Label="First Name"
                  Function={setFirstName}
                />
                <Input
                  Type="text"
                  Value={lastName}
                  Label="Last Name"
                  Function={setLastName}
                />

                <Input
                  Type="email"
                  Value={email}
                  Label="Email"
                  Function={setEmail}
                />
                <Input
                  Type="number"
                  Value={phoneNumber}
                  Label="Phone Number"
                  Function={setPhoneNumber}
                />

                <Font.Human margin="11px 0 0 0" color={Color.darkestBlue}>
                  Leave Us a Message
                </Font.Human>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  style={{
                    width: "289px",
                    height: "125px",
                    border: "1.5px solid #035388",
                    backgroundColor: "transparent",
                    fontSize: "18px",
                  }}
                />
              </div>
              <MButton
                margin="16px 0 19px 0"
                width="180px"
                onClick={handleSubmit}
              >
                <Font.Human color="white" textAlign="center">
                  Send Feedback
                </Font.Human>
              </MButton>
            </form>
          </div>
        </div>

        <img
          src={RestaurantImg}
          alt="Restaurant"
          style={{
            zIndex: -4,
            marginTop: "0px",
            height: "203px",
            width: "100%",
          }}
        />
        <Font.Jupiter
          color={Color.darkestBlue}
          backgroundColor={Color.brightestBlue}
          width="210px"
          margin="-39px 0 0 0"
          padding="14px 72px 14px 72px"
          style={{ zIndex: 100 }}
        >
          Visit Us
        </Font.Jupiter>

        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3682.2219136743156!2d14.524174215370863!3d-22.645513285145302!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1c76591260f6c1ef%3A0x1a2a19e24723dc9d!2sRandom%20Cafe!5e0!3m2!1sen!2smy!4v1639663136954!5m2!1sen!2smy"
          width="100%"
          height="620"
          frameborder="0"
          style={{ border: 0 }}
          allowfullscreen=""
          aria-hidden="false"
          tabindex="0"
          style={{
            display: "block",
            padding: 0,
            margin: "-14px 0 0 0",
          }}
        ></iframe>
      </div>
      <MobileFooter />
    </div>
  );
};

const Input = ({ Type, Label, Value, Function }) => {
  return (
    <div>
      <Font.Human margin="11px 0 0 0" color={Color.darkestBlue}>
        {Label}
      </Font.Human>
      <input
        type={Type}
        value={Value}
        onChange={(e) => Function(e.target.value)}
        style={{
          width: "185px",
          height: "23px",
          border: "1.5px solid #035388",
          backgroundColor: "transparent",
          fontSize: "18px",
        }}
      />
    </div>
  );
};
