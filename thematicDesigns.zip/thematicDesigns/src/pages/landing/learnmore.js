import React from "react";
import * as Font from "_styles/font";
import * as Color from "_styles/color";
import * as Buttons from "_components/button";

import home3_3 from "_images/home3-3.jpg";
import home3_2 from "_images/home3-2.jpg";
import home3 from "_images/home3copy.jpg";

import { NavLink } from "react-router-dom";

export const LearnMore = () => {
  return (
    <div
      style={{
        display: "flex",
        height: "500px",
        width: "100%",
        margin: "104px 0",
        justifyContent: "space-around",
      }}
    >
      <LeftBox />
      <MiddleBox />
      <RightBox />
    </div>
  );
};

const LeftBox = () => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "500px",
        width: "31%",
      }}
    >
      <img
        src={home3_2}
        alt=""
        style={{
          // position: "absolute",
          margin: "0 5% auto auto",
          objectFit: "contain",
          minWidth: "300px",
          width: "50%",
          // right: "70px",
        }}
      />
      <img
        src={home3_3}
        alt=""
        style={{
          objectFit: "contain",
          margin: "auto auto 0 5%",
          minWidth: "330px",
          width: "60%",
        }}
      />
    </div>
  );
};

const MiddleBox = () => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        backgroundColor: Color.darkerOrange,
        height: "500px",
        minWidth: "500px",
        width: "34%",
        // zIndex: "1",
        padding: "36px 60px 244px 60px",
        boxSizing: "border-box",
      }}
    >
      {/* <div> */}
      <Font.Ocean color={Color.brightestOrange}>
        A recipe perfected over 5 generations
      </Font.Ocean>
      <Font.Basketball margin="36px 0" color={Color.brightOrange}>
        I'm a paragraph. Click here to add your own text and edit me. It’s easy.
        Just click “Edit Text” or double click me to add your own content and
        make changes to the font. I’m a great place for you to tell a story and
        let your users know a little more about you.
      </Font.Basketball>
      <div
        style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <NavLink to="/about">
          <Buttons.Button bgColor={Color.brighterBlue}>
            <Font.Hair style={{ textAlign: "center" }} color={Color.darkOrange}>
              Check out our Story
            </Font.Hair>
          </Buttons.Button>
        </NavLink>
      </div>
    </div>
  );
};

const RightBox = () => {
  return (
    <div
      style={{
        position: "relative",
        display: "flex",
        backgroundColor: "transparent",
        height: "500px",
        width: "31%",
        justifyContent: "left",
      }}
    >
      <img
        src={home3}
        alt=""
        style={{
          margin: "auto 5% ",
          height: "100%",
          width: "100%",
          objectFit: "cover",
        }}
      />
    </div>
  );
};
