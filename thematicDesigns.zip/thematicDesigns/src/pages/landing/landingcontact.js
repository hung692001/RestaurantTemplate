import React from "react";
import * as Font from "_styles/font";
import * as Color from "_styles/color";
import * as Buttons from "_components/button";

import home4 from "_images/home4.jpg";
import { NavLink } from "react-router-dom";

export const LandingContact = () => {
  return (
    <div
      style={{
        display: "flex",
        height: "600px",
        width: "100%",
      }}
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: Color.darkerBlue,
          height: "700px",
          width: "45%",
          padding: "35px 90px 100px 90px",
          justifyContent: "center",
          boxSizing: "border-box",
        }}
      >
        <Font.Ocean color={Color.brightestOrange}>
          No Korean Dining Experience is Complete without Friends and Family
        </Font.Ocean>

        <Font.Basketball color={Color.brightOrange} margin="36px 0">
          I'm a paragraph. Click here to add your own text and edit me. It’s
          easy. Just click “Edit Text” or double click me to add your own
          content and make changes to the font. I’m a great place for you to
          tell a story and let your users know a little more about you.
        </Font.Basketball>
        <div>
          <NavLink to="/connectwithus">
            <Buttons.Button
              alignSelf="left"
              margin="30px 0"
              height="70px"
              bgColor={Color.brighterBlue}
            >
              <Font.Hair
                style={{ textAlign: "center" }}
                color={Color.darkerBlue}
              >
                Contact Us
              </Font.Hair>
            </Buttons.Button>
          </NavLink>
        </div>
      </div>
      <img
        src={home4}
        alt="next to landing intro img"
        style={{
          width: "55%",
          height: "700px",
          objectFit: "cover",
        }}
      />
    </div>
  );
};
