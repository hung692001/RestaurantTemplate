import React from "react";
import * as Font from "_styles/font";
import * as Color from "_styles/color";
import * as Buttons from "_components/button";

import home1 from "_images/home1.jpg";
import { NavLink } from "react-router-dom";

export const Greet = () => {
  return (
    <div
      style={{
        display: "flex",
        backgroundColor: Color.lighterOrange,
        height: "900px",
        width: "100%",
      }}
    >
      <GreetText />
      <img
        src={home1}
        alt="next to landing intro img"
        style={{
          width: "50%",
          height: "1000px",
          objectFit: "cover",
        }}
      />
    </div>
  );
};

const GreetText = () => {
  return (
    <div
      style={{
        display: "flex",
        backgroundColor: Color.lighterOrange,
        height: "900px",
        width: "50%",
        minWidth: "700px",
        paddingLeft: "100px",
        flexDirection: "column",
        boxSizing: "border-box",
        justifyContent: "center",
        marginTop: "100px",
      }}
    >
      <Font.Sun color={"white"}>
        Your Favourite Korean Foods Just an Order Away
      </Font.Sun>
      <div>
        <NavLink to="/about">
          <Buttons.Button margin="120px 0" alignSelf="start">
            <Font.Hair
              style={{ textAlign: "center" }}
              color={Color.lighterOrange}
            >
              Check out our Story
            </Font.Hair>
          </Buttons.Button>
        </NavLink>
      </div>
    </div>
  );
};
