import React from "react";
import * as Font from "_styles/font";

import image4_1 from "_images/home4-1.jpg";
import image4_2 from "_images/home4-2.jpg";
import image4_3 from "_images/home4-3.jpg";

export const SampleMenu = () => {
  return (
    <div
      style={{
        display: "flex",
        height: "650px",
        width: "100%",
        justifyContent: "space-around",
      }}
    >
      <Section1
        img={image4_1}
        title="Japchae"
        description="Something nice about japchae"
      />
      <Section1
        img={image4_2}
        title="KimChi Pancakes"
        description="Something nice about japchae"
      />
      <Section1
        img={image4_3}
        title="Doenjangg Jiggae"
        description="Something nice about japchae"
      />
    </div>
  );
};

const Section1 = ({ img, title, description, alt }) => {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        minWidth: "400px",
        width: "30%",
        alignItems: "center",
      }}
    >
      <img
        src={img}
        alt={alt}
        style={{
          // top: "0",
          height: "70%",
          width: "90%",
          objectFit: "cover",
          minWidth: "300px",
        }}
      />
      <Font.Basketball margin="10px 0 15px 0">{title}</Font.Basketball>
      <Font.Bacteria>{description}</Font.Bacteria>
    </div>
  );
};
