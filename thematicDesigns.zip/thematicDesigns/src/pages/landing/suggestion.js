import React from "react";
import * as Font from "_styles/font";
import * as Color from "_styles/color";
import * as Buttons from "_components/button";

import home2 from "_images/home2.jpg";
//JK TO REVIEW
export const Suggestion = () => {
  return (
    <div
      style={{
        backgroundColor: Color.brighterOrange,
        width: "904px",
        display: "flex",
        height: "670px",
        margin: "auto",
        zIndex: "5",
        boxSizing: "border-box",
      }}
    >
      <img
        src={home2}
        alt="second img"
        style={{
          width: "50%",
          height: "100%",
          objectFit: "cover",
        }}
      />
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          backgroundColor: Color.brighterBlue,
          height: "100%",
          width: "50%",
          padding: "86px 38px 0 49px",
          boxSizing: "border-box",
        }}
      >
        <Font.Ocean color={Color.darkestBlue}>
          Try Our Signature Korean Fried Chicken
        </Font.Ocean>

        <Font.Basketball color={Color.darkerBlue} margin="48px 0">
          I'm a paragraph. Click here to add your own text and edit me. It’s
          easy. Just click “Edit Text” or double click me to add your own
          content and make changes to the font. I’m a great place for you to
          tell a story and let your users know a little more about you.
        </Font.Basketball>

        <Buttons.Button>
          <Font.Hair
            style={{ textAlign: "center" }}
            color={Color.lightestOrange}
          >
            Order Now
          </Font.Hair>
        </Buttons.Button>
      </div>
    </div>
  );
};
