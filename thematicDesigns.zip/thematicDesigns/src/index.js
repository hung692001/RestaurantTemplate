import React, { useContext, useEffect } from "react";
import ReactDOM from "react-dom";
import "_styles/index.css";

import { HomePage } from "_pages/home";
import { AboutPage } from "_pages/about";
import { Footer } from "_components/footer";
import reportWebVitals from "./reportWebVitals";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import { ScreenSizeProvider } from "_store/screen-size";
import { Routing } from "_pages";

ReactDOM.render(
  <Router>
    <App />
  </Router>,
  document.getElementById("root")
);

function App() {
  return (
    <ScreenSizeProvider>
      <Routing />
    </ScreenSizeProvider>
  );
}

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
